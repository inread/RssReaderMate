//给主app使用
(function() {
     try{
        if(ExtensionPreprocessingJS && ExtensionPreprocessingJS.getLastHash()==false){
            var kv = ExtensionPreprocessingJS.inCheck();
            ExtensionPreprocessingJS.setLastHash(kv);
            var ret = new Object();
            ret['s'] = kv;
            bj_EventCallToApp('j2a_rssinfo', ret);
        }
     }catch(e){
         console.log('action web e:'+e);
     }
 
})();
