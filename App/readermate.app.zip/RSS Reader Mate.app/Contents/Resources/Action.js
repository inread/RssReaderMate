var Action = function() {
    this.mLasthash=false;
};

Action.prototype = {
    getLastHash:function(){
        return this.mLasthash;
    },
    setLastHash:function(hs){
        this.mLasthash=hs;
    },
    check: function() {
        var rssurl = "";
        var otherrssurls =[];
        var isdiscuz =false;
        var discuz ={};
        try{
            rssurl = window.location.href;
        }catch(e){
            rssurl = "";
            this.log("href:"+e);
        }
        try{
            otherrssurls = this.getRSSUrls();
        }catch(e){
            otherrssurls =[];
            this.log("rss:"+e);
        }
        try{
            isdiscuz = this.isDiscuzSite();
            if(isdiscuz){
                discuz=this.discuzSiteHandle();
            }
        }catch(e){
            this.log("discuz:"+e);
        }
        try{
            iscsdn = this.isCSDNBlog();
            if(iscsdn){
                var cb= this.csdnBlogHandle();
                if(cb){
                    otherrssurls.push(cb);
                }
            }
        }catch(e){
            otherrssurls =[];
            this.log("rss:"+e);
        }
        var selectedStr =window.getSelection().toString();
        if(!selectedStr){
            selectedStr="";
        }
        var selectedHtml =this.selectedHTML();
        if(!selectedHtml){
            selectedHtml="";
        }
        var uri = this.docBaseURI();
        if(!uri){uri="";}
        var kv= {
        "js_baseURI": uri,
        "js_rssurl":rssurl,
        "js_rsslinks" : otherrssurls,
        "js_isdiscuz" :isdiscuz,
        "js_discuz" :discuz,
        "js_selectedHtml":selectedHtml,
        "js_selectedStr":selectedStr,
        "js_result":1,
        };
        return kv;
    },
    run: function(arguments) {
         if(arguments){
            arguments.completionFunction(this.check());
         }
    },
    finalize: function(arguments) {
        var rjs =arguments["script"];
        try{
            if(rjs){
               eval(rjs);
            }
        }catch(e){
            
        }
    },
    inCheck: function() {
        var obj= this.check();
        
        
        return obj;
    },
    log:function(e){
        //console.log('action log:'+ e);
    },
    isArray:function(s){
        var ret = false;
        try {if (Array.isArray(s))  {ret = true;} }
        catch (e) {}
        return ret;
    },

    isString:function(s){
        var r =false;
        if(s){if (s===undefined){}else if((typeof s ==='string' )){r =true;}}
        return r;
    },
    
    docBaseURI:function(){
        var r= document.baseURI;
        return r?r:"";
    },

    selectedHTML:function(){
        var range;
        if (document.selection && document.selection.createRange) {
            range = document.selection.createRange();
            return range.htmlText;
        } else if (window.getSelection) {
            var selection = window.getSelection();
            if (selection.rangeCount > 0) {
                range = selection.getRangeAt(0);
                var clonedSelection = range.cloneContents();
                var div = document.createElement('div');
                div.appendChild(clonedSelection);
                return div.innerHTML;
            } else {
                return '';
            }
        } else {
            return '';
        }
    },
    regx:function(s,r,c=1){
        var rc=null;
        try {
            var m = s.match(r);
            if ((m!=null)&&  (m.length > c)) {
                rc = m[c];
            }
        } catch (e) {
            rc =null;
        }
        return rc;
    },
    isMatch:function(s,r){
        var rc=false;
        try {
            var m = s.match(r);
            if ((m!=null)&&  (m.length > 0)) {
                rc = true;
            }
        } catch (e) {
        }
        return rc;
    },
    regxArray:function(url,regxs,callFunc){
        for(var i =0; i< regxs.length; i++){
            var rc= this.regx(url,regxs[i],1);
            if(rc!=null)
            {
                if(callFunc&& (callFunc(this,rc)==false)){
                    break;
                }
            }
        }
    },
    xpath:function (x=null,xmlDom=false,root=false) {
        var nodes = [];
        if(!x || (typeof x == 'undefined') || x==null ){
            this.log('xpath invalid');
            return nodes;
        }
        if (!xmlDom) {
            xmlDom = document;
        }
        if (typeof xmlDom.evaluate != 'undefined') {
            var result = xmlDom.evaluate(x, root?root:xmlDom, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
            if (result != null) {
                var node = null;
                while ((node = result.iterateNext()) != null) {
                    nodes.push(node);
                }
            }
        }else{
            this.log('evaluate invalid');
        }
        return nodes;
    },
    xpathArray:function (xs,callFunc) {
        if(!xs || (typeof xs == 'undefined') || xs==null){
            console.log('xpath list invalid');
            return;
        }
        if(this.isArray(xs)){
            for(var i=0; i<xs.length; i++){
                var rs = this.xpath(xs[i]);
                for(var j=0; j<rs.length; j++){
                    if (callFunc){
                        callFunc(this,rs[j],j,i);
                    }
                }
            }
        }
    },
    getXPATHLISTLinks : function(list,callFunc){
        var count =0;
        this.xpathArray(
            list,
            function(p,e,j,i){
                var str= e.href;
                if(str &&  (typeof str ==='string' ) && str.startsWith('http')){
                    callFunc(p,str);
                    count+=1;
                }         
                else{
                    this.log('a href not string');
                }
            }
        );
        return count;
    },
    getRSSUrls : function(){
        var rets = [];
        this.getRSSLinks(function(p,url){
                         if(url && rets.indexOf(url)<0){
                            rets.push(url);
                         }
                         });
        this.log('getRSSA:'+ rets.length);
        return rets;
    },
    getRSSLinks : function(callFunc){
        var xs =  [
                   "//link[@href][contains(@type,'rss+xml') or contains(@type,'atom+xml')]",
                      "//a[@href][contains(@class,'rss') or contains(@class,'feed') or contains(@href,'rss') or contains(@href,'feed') ]/*[contains(@class,'rss') or contains(@class,'feed') ]/..",
                      "//a[@href][contains(@href,'/feed.xml') or contains(@href,'/rss.xml') or contains(@href,'/atom.xml') ]",
                      "//a[contains(@href,'=rss')][@title='RSS']",
                      "//a[contains(@href,'rss')][text()='RSS'][count(child::node)=0]",
                      "//a[contains(@href,'rss')][count(child::node)=0]"
                  ];
        return this.getXPATHLISTLinks(xs,callFunc);
    },
    icons:function(){
        var rets = [];
        var xs =[
            "//link[@rel='icon'][@href]",
            "//link[@rel='shortcut icon'][@href]",
            "//link[@rel='apple-touch-icon'][@href]",
            "//link[contains(@rel,'SHORTCUT')][@href]",
        ];
        this.getXPATHLISTLinks(xs,function(p,url){
        if(url && rets.indexOf(url)<0){
           rets.push(url);
        }
        });
        return rets;
    },
    isDiscuzSite:function(){
        return ( this.isMatch(window.document.location.href,"forum-([a-zA-Z0-9]+)-") ||
        this.isMatch(window.document.location.href,"forum.php") ||
        this.xpath("//*[contains(.,'Discuz')]").length>0)?true:false;
    },
    discuzSiteHandle:function(){
        var info ={};
        var urlList = [];
        var baseStr= window.document.location.protocol+"//" +window.document.location.host+ window.document.location.port +'/forum.php';
        urlList.push(baseStr +'?mod=rss');
        
        this.regxArray(window.document.location.href,["forum-(\\d+)-","fid[=|-](\\d+)"],function(p,r){
            var t=baseStr +"?fid="+r+"&mod=rss";
            if(urlList.indexOf(t)<0){ urlList.push(t); }
            return false;
        });
        
        this.xpathArray(
        [
        "//a[not(contains(@href,'gid'))][(contains(@href,'forum.php') and contains(@href,'fid=') ) or (contains(@href,'forum-') and contains(@href,'.html') )]"
         ],function(p,e,j,i){
            var eh =e.href;
            var fid=  p.regx(eh,"forum-(\\d+)-",1);
            if(fid==null){
                fid= p.regx(eh,"fid[=|-](\\d+)",1);
            }
            if(fid!=null){
                var u=baseStr +"?fid="+fid+"&mod=rss";
                if(urlList.indexOf(u)<0){ urlList.push(u); }
            }
        });
        
        this.xpathArray(
        [
        "//a[contains(@href,'.php') and contains(@href,'catid=') and contains(@href,'mod=list')]"
         ],function(p,e,j,i){
            var eh =e.href;
            if(eh){
                var u=eh.replace('mod=list','mod=rss');
                if(u&&(urlList.indexOf(u)<0)){ urlList.push(u); }
            }
        });
        return urlList;
    },
    isCSDNBlog:function(){
        return this.isMatch(window.document.location.href,"blog.csdn.net/[a-zA-Z0-9_]+/")||
        this.isMatch(window.document.location.href,"me.csdn.net/[a-zA-Z0-9_]+/");
    },
    csdnBlogHandle:function(){
        return window.document.location.protocol+"//blog.csdn.net/"+ window.document.location.pathname.split('/')[1]+'/rss/list';
    },
};

var ExtensionPreprocessingJS = new Action

//(function() {
//
//     if (window.top != window.self) {
// alert('ddd');
//         return
//     }
//
//    document.addEventListener("DOMContentLoaded", function(event) {
//        done = true
//        var links = document.querySelectorAll('link');
//        var found = "false";
//        var lk ="";
//        for (const link of links) {
//            if (link.hasAttribute("rel") && link.getAttribute("rel").toLowerCase() == "alternate" && link.hasAttribute("href") && link.hasAttribute("type")) {
//                var type = link.type.toLowerCase();
//                if (type.indexOf("rss") > -1 || type.indexOf("atom") > -1 || type.indexOf("application/json") > -1) {
//                    found = "true";
//                    lk= link.href;
//                    break;
//                }
//            }
//        }
//        alert('ddd='+lk);
//        //safari.extension.dispatchMessage(found);
//
//    });
//})();
